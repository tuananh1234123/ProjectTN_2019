package poly.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import poly.Services.*;

@Service
public class HomeServiceImpl implements HomeService {

	@Override
	public List<String> loadMenu() {
		List<String> menus = new ArrayList<>();
		
		return menus;
	}
}
