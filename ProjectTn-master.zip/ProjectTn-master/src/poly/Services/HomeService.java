package poly.Services;

import java.util.List;

public interface HomeService {
	List<String> loadMenu();
}
